
create database castrosbank

use castrosbank

drop table Poupanca
select * from Poupanca
select * from corrente
select * from especial
select * from empresa
select * from estudantil