import pandas as pd
import os

pd.set_option("display.max_columns",None)#mostra todas as colunas

fem_df = pd.read_csv("Feminicidio.csv")

# print(fem_df)


#quantidade anual
anual = fem_df[['ANO_ESTATISTICA','VITIMAS']].groupby('ANO_ESTATISTICA').sum()

print(anual)

